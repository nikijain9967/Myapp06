//step1: include your mob=ngoose
const mongoose=require('mongoose');
const Schema=mongoose.Schema;
//step2: create a collection using schema 
//mongoose allows us to work with collection as an object
//it ac t as an ORM 
// new schema ({attributes in doucment},{anme of collection})
let Employee=new Schema({
    empId:{type:Number},
    empName:{type:String},
    designation:{type:String},    
},{
    collection: 'employee'
});
//to access your doucment created in mongodb as an object we call mongoose.model("Employee",Employee);
//model(name of module to be exported, module)
module.exports=mongoose.model("Employee",Employee);