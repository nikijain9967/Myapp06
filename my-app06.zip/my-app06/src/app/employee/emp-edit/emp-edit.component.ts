import { Component, OnInit, Input } from '@angular/core';
import { Employee } from '../employee';
import { ActivatedRoute } from '@angular/router';
import { EmpServiceService } from '../service/emp-service.service';

@Component({
  selector: 'app-emp-update',
  templateUrl: './emp-edit.component.html',
  styleUrls: ['./emp-edit.component.css']
})
export class EmpUpdateComponent implements OnInit {
  @Input()
  employee:Employee;
  
  constructor(private route:ActivatedRoute,private service:EmpServiceService) { }

  ngOnInit() {
     }
  updateEmployee(empId:any,desig:any){
    this.service.updateEmployee(empId,desig);
  }

}